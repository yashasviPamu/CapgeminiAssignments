import { AdModel } from './ad-model';

describe('AdModel', () => {
  it('should create an instance', () => {
    expect(new AdModel()).toBeTruthy();
  });
});