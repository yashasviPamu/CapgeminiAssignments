package com.example.SpringSecurityQ1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityQ1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
