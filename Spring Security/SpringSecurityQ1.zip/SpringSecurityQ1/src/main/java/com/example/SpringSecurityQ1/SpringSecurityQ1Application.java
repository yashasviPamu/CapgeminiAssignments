package com.example.SpringSecurityQ1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityQ1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityQ1Application.class, args);
	}

}
