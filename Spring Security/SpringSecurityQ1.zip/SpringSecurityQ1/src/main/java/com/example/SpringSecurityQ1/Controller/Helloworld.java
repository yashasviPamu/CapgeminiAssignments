package com.example.SpringSecurityQ1.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Helloworld {

    @GetMapping("/")
    public String home() {

        return ("<h1>Hello World!</h1>");
    }
}
