package com.example.SpringSecurityQ3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityQ3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
