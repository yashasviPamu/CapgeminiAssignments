package com.example.SpringSecurityQ4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityQ4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityQ1Application.class, args);
	}

}
