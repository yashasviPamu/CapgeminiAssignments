package beans;

public interface Drawing {
    public void draw();
}
