package Assignment;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class controller {
	@RequestMapping(value = "/emp/{str}/{id}", method = RequestMethod.GET)
	public ModelAndView getValues(@PathVariable Map<String, String> p) {
		ModelAndView mv = new ModelAndView("login");

	    String str = p.get("str"); 
	    String id = p.get("id"); 
		String a = "";

		if (str.equals("delete")) {
			a = "DELETE FROM employee WHERE employee_id='" + id + "'";
			mv.addObject("Emp", "Employee Table After Deletion");
		}
		if (str.equals("findAll")) {
			a = "SELECT * FROM employee";
			mv.addObject("Emp", " Employee Table");
		}

		ArrayList<EmployeeDetails> ll = ConnectDB.getDetails(a);
		
		if(id.equals("x")) {
			return new ModelAndView(new toExcel(),"list",ll);
		}
		if(id.equals("p")) {
			return new ModelAndView(new toPdf(),"list",ll);
		}

		mv.addObject("list", ll);
		return mv;
	}

	@RequestMapping(value = "/em/{str}/{id}", method = RequestMethod.GET)
	public ModelAndView getVal(@PathVariable Map<String, String> p) {
		ModelAndView mv = new ModelAndView("DataChange");

		String str = p.get("str");
		String id = p.get("id");
		
		if(str.equals("search")) 
		{
			mv.addObject("Search", "Search with any one attribute");
		}
		else 
		{
			mv.addObject("Search", str);
		}
		mv.addObject("id", id);

		return mv;
	}

	@RequestMapping(value = "/empl/{str}/{id}", method = RequestMethod.POST)
	public ModelAndView getValues(@PathVariable Map<String, String> p, @ModelAttribute("user") EmployeeDetails user) {
		ModelAndView mv = new ModelAndView("login");

		String str = p.get("str");
		String id = p.get("id");

		String a = "";
		if (str.equals("search")) {
			if(!user.getEid().equals("null")) {a = "SELECT * FROM employee WHERE employee_id='" + user.getEid() + "'";}
			if(!user.getEname().equals("null")) {a = "SELECT * FROM employee WHERE employee_id='" + user.getEname() + "'";}
			if(!user.getEdepartment().equals("null")) {a = "SELECT * FROM employee WHERE employee_id='" + user.getEdepartment() + "'";}
			if(!user.getEdesignation().equals("null")) {a = "SELECT * FROM employee WHERE employee_id='" + user.getEdesignation() + "'";}
			if(user.getEsalary().equals("0")) {a = "SELECT * FROM employee WHERE employee_id='" + user.getEsalary() + "'";}
			
			mv.addObject("empTable", "Table After Search");
		}
		
		
		if (str.equals("add")) {
			a = "INSERT INTO Registration(employee_id, employee_name, employee_department, employee_designation, employee_salary) "
					+ "VALUES ('" + user.getEid() + "', '" + user.getEname() + "', '" + user.getEdepartment() + "', '"
					+ user.getEdesignation() + "', '" + user.getEsalary() + "')";
			mv.addObject("empTable", "New Employee Table");
		}
		
		
		if (str.equals("edit")) {
			a = "UPDATE employee SET employee_id= '" + user.getEid() + "',employee_name = '" + user.getEname()
					+ "',employee_department = '" + user.getEdepartment() + "' ,employee_designation = '"
					+ user.getEdesignation() + "' ,employee_salary = '" + user.getEsalary() + "' WHERE employee_id='" + id
					+ "'";
			mv.addObject("empTable", "Updated Employee Table");
		}

		ArrayList<EmployeeDetails> ll = ConnectDB.getDetails(a);

		mv.addObject("list", ll);
		return mv;
	}

}
