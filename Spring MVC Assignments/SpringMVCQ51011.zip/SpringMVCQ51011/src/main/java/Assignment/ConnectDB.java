package Assignment;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ConnectDB {
public static ArrayList<EmployeeDetails> getDetails(String s){
		
		ArrayList<EmployeeDetails> list= new ArrayList<>();
		
		String url="jdbc:mysql://localhost:3306/emp";
		String userName="Yashu";
		String passWord="252818";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
			java.sql.Connection con= DriverManager.getConnection(url,userName,passWord);
			java.sql.Statement statement= con.createStatement();
			ResultSet resultSet= statement.executeQuery(s);
			while(resultSet.next()) {
				String str1=resultSet.getString("employee_id");
				String str2= resultSet.getString("employee_name");
				String str3= resultSet.getString("employee_department");
				String str4= resultSet.getString("employee_designation");
				String str5= resultSet.getString("employee_salary");
				
				list.add( new EmployeeDetails(str1,str2,str3,str4,str5));

				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}
}
