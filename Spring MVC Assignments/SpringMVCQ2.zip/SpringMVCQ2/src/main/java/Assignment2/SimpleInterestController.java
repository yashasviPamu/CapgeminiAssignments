package Assignment2;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller 
public class SimpleInterestController {
	@RequestMapping(value = "/getSi",method = RequestMethod.GET)
	public ModelAndView getValues(){		
		ModelAndView mv =new ModelAndView("InterestInput");
		mv.addObject("Salutation","Hello! Welcome to Simple Interest Calculator");
		return mv;
	}
	
	 @RequestMapping(value = "/addSi", method = RequestMethod.POST) 
	   public ModelAndView showValue(@ModelAttribute("Si") SimpleInterestClass Si) { 
		  System.out.println("Hello");
	      ModelAndView model=new ModelAndView("Calculate");
	      return model; 
	   }
}
