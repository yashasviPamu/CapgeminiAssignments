package Assignment2;

public class SimpleInterestClass {
	private int principal;
	private double rate;
	private int years;
	private double interest;
	
	public int getPrincipal() {
		return principal;
	}
	public void setPrincipal(int principal) {
		this.principal = principal;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}
	
	public double calculate()
	{
		interest= (principal*rate*years)/100;
		return interest;
	}
}
