package Assignment3;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

public class Controller {
	
	@RequestMapping(value="/Login",method = RequestMethod.GET)
	public ModelAndView getLoginPage() {
		ModelAndView mv = new ModelAndView("login");
		return mv;
	}
	
	@RequestMapping(value="/submitLogin",method = RequestMethod.POST)
	public ModelAndView auth(@ModelAttribute("credentials") Credentials credentials) {
		ArrayList<Credentials> list = Auth.getDetails();
		for(Credentials cred:list)
		{
			if(cred.equals(credentials)) {
				ModelAndView mv =new ModelAndView("success");
				return mv;
			}
		}
		ModelAndView mv=new ModelAndView("error");
		return mv;
	}
}
