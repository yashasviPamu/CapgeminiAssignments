package Assignment3;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Auth {
    public static ArrayList<Credentials> getDetails(){
	   ArrayList<Credentials> list= new ArrayList<>();
	   String url="jdbc:mysql://localhost:3306/";
		String user = "Yashu";
		String pass = "252818";
		try {
			java.sql.Connection con= DriverManager.getConnection(url,user,pass);
			java.sql.Statement statement= con.createStatement();
			ResultSet resultSet= statement.executeQuery("SELECT * FROM cred");
			while(resultSet.next()) {
				String userName=resultSet.getString("username");
				String passWord= resultSet.getString("password");
				
				list.add( new Credentials(userName, passWord));

				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
    }
	   
}
