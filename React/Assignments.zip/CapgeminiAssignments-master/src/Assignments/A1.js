import React from 'react'

function A1() {
    return (
        <div>
            <h1>Hello World</h1>
        </div>
    )
}

export default A1
