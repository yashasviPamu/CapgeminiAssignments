import React from 'react';
  
const Services = () => {
  const mystyle = {
    color: "white",
    backgroundColor: "DodgerBlue",
    padding: "10px",
    fontFamily: "Arial"
  };
  return (
   
    
      <h1 style={mystyle}>services</h1>
   
  );
};
  export default Services;