import React from 'react';
  
const Products = () => {
  const mystyle = {
    color: "white",
    backgroundColor: "DodgerBlue",
    padding: "10px",
    fontFamily: "Arial"
  };
  return (
   
    
      <h1 style={mystyle}>product</h1>
   
  );
};
export default Products;