import React from 'react';
  
const contacts = () => {
  const mystyle = {
    color: "white",
    backgroundColor: "DodgerBlue",
    padding: "10px",
    fontFamily: "Arial"
  };
  return (
   
    
      <h1 style={mystyle}>contact</h1>
   
  );
};
  export default contacts;