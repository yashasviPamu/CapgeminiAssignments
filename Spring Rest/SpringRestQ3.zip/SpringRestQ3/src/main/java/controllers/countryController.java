package controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import models.countryModel;

@RestController
public class countryController {
	@RequestMapping(value = "/country/{zipcode}", method = RequestMethod.GET,headers="Accept=application/json")
    public String getCountryById(@PathVariable int zipcode){
        List<countryModel> listOfCountries = new ArrayList<countryModel>();
        listOfCountries=createCountryList();
 
        for (countryModel country: listOfCountries) {
            if(country.getZipcode()==zipcode)
                return country.toString();
        }
 
        return null;
    }
	@RequestMapping("/getCountry")
	public String getCountry(@RequestParam("code") String zcode) {
		long zipcode = Integer.parseInt(zcode);
		List<countryModel> listOfCountries = new ArrayList<countryModel>();
        listOfCountries=createCountryList();
 
        for (countryModel country: listOfCountries) {
            if(country.getZipcode()==zipcode)
                return country.toString();
        }
 
        return null;
	}
	
	public List<countryModel> createCountryList(){
	        countryModel c1=new countryModel(500035, "Telangana","Hyderabad","India");
	        countryModel c2=new countryModel(106-0022, "Tokyo","Shinjuku", "Japan");
	        countryModel c3=new countryModel(90210, "California","Beverly Hills", "US");
	 
	        List<countryModel> listOfCountries = new ArrayList<countryModel>();
	        listOfCountries.add(c1);
	        listOfCountries.add(c2);
	        listOfCountries.add(c3);
	        return listOfCountries;
	}
}