package com.example.controller;

import java.util.List;

import com.example.model.orders;
import com.example.repository.OrdersDomainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrdersDomainController {
	
	@Autowired
	private OrdersDomainRepository ordersRepo;

	@GetMapping("/orders")
	public List<orders> getAll(){
		return ordersRepo.findAll();
	}
	
	@PostMapping("/orders")
	public orders createOrder(@RequestBody orders orders) {
		ordersRepo.save(orders);
		return orders;
	}
	@GetMapping("/orders/{orderId}")
	public orders getById(int orderId)
	{
		return ordersRepo.findById(orderId).get();
	}
	@PutMapping("/orders/{orderId}")
	public orders updateOrderById(@PathVariable("orderId") int orderId, @RequestBody orders orders) {
		orders.setOrderId(orderId);
		ordersRepo.save(orders);
		return orders;
	}
	
	@DeleteMapping("/orders/{orderId}")
	public int deleteOrders(@PathVariable("orderId") int orderId) {
		ordersRepo.deleteById(orderId);
		return orderId;
	}
}
