package com.example.repository;

import com.example.model.orders;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface OrdersDomainRepository extends MongoRepository<orders, Integer> {

}