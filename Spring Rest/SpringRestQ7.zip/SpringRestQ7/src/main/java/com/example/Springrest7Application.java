package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springrest7Application {

	public static void main(String[] args) {
		SpringApplication.run(Springrest7Application.class, args);
}
}