package controllers;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import models.UserModel;

@RestController
public class AuthController {
	@RequestMapping("/auth.html")
	public String userAuth(@ModelAttribute("userModel1") UserModel userModel1) {
		//callAuthenticator
		boolean isValid = Checks(userModel1.getUsername(),userModel1.getPassword());
		if(isValid) {
			return "valid user";
		}
		return "Invalid user";
		
	}
	
	public boolean Checks(String username, String pass) {
		if(username.contentEquals("Seuho") && pass.equals("2528")) {
			return true;
		}
		return false;
	}
}