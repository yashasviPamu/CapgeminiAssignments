package com.example;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CalculationController {
	
@RequestMapping("/add")
@ResponseBody
public int giveAdd(@RequestParam("num1") int n,@RequestParam("num2") int m) {
	int result=n+m;
	return result;
	}


@RequestMapping("/subtract")
@ResponseBody
public int giveSubract(@RequestParam("num1") int n,@RequestParam("num2") int m) {
	int result=n-m;
	return result;}
@RequestMapping("/multiply")
@ResponseBody
public int giveMultiply(@RequestParam("num1") int n,@RequestParam("num2") int m) {
	int result=n*m;
	return result;}
@RequestMapping("/divide")
@ResponseBody
public float giveDivision(@RequestParam("num1") int n,@RequestParam("num2") int m) {
	float result=n/m;
	return result;}
}