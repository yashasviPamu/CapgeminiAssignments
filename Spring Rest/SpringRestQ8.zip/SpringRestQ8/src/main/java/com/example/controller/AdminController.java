package com.example.controller;

import com.example.model.AdminModel;
import com.example.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AdminController {
    @Autowired
    AdminService adminService;
    @GetMapping("/admin")

    private List<AdminModel> getList()
    {
        return adminService.getList();
    }

    @GetMapping("/admin/{product_id}")
    private AdminModel getFlights(@PathVariable("product_id") int product_id)
    {
        return adminService.getById(product_id);
    }
    @DeleteMapping("/admin/{product_id}")
    private ResponseEntity<?> deleteFlight(@PathVariable("product_id") int product_id)
    {
        adminService.delete(product_id);
        return new ResponseEntity<>("Successfully deleted with id "+product_id, HttpStatus.OK);
    }
    @PostMapping("/admin")
    private ResponseEntity<?> saveFlightDetails(@RequestBody AdminModel admin)
    {
        adminService.saveOrUpdate(admin);
        return new ResponseEntity<>("Successfully Saved with Details ", HttpStatus.OK);
    }
    @PutMapping("/admin")
    private ResponseEntity<?> updateFlightDetails(@RequestBody AdminModel admin)
    {
        adminService.saveOrUpdate(admin);
        return new ResponseEntity<>("Successfully Updated with Details ", HttpStatus.OK);
    }

}
