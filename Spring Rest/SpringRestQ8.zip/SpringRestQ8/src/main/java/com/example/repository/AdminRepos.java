package com.example.repository;

import com.example.model.AdminModel;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AdminRepos extends MongoRepository<AdminModel, Integer> {
}
