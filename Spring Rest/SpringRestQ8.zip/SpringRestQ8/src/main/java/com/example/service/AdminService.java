package com.example.service;

import com.example.model.AdminModel;
import com.example.repository.AdminRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminService {



    @Autowired
    AdminRepos adminRepository;
    public List<AdminModel> getList()
    {
        List<AdminModel> List = new ArrayList<AdminModel>();
        adminRepository.findAll().forEach(List1 -> List.add(List1));return List;
    }
    public AdminModel getById(int product_id)
    {
        return adminRepository.findById(product_id).get();
    }

    public void saveOrUpdate(AdminModel adminModel)
    {
        adminRepository.save(adminModel);
    }

    public void delete(int product_id)
    {
        adminRepository.deleteById(product_id);
    }

    public void update(AdminModel adminModel, int product_id)
    {
        adminRepository.save(adminModel);
    }

}
