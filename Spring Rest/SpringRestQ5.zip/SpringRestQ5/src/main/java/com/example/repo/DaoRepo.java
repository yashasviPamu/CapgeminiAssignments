package com.example.repo;



import com.example.model.Employee;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DaoRepo extends CrudRepository<Employee, Long> {
	
}