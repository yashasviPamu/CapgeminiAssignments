package com.example.comtroller;

import java.util.List;

import com.example.model.Employee;
import com.example.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeController {
    @Autowired
    EmpService empService;

    @GetMapping("/employees")

    private List<Employee> getFlightsList() {
        return empService.getList();
    }

    @GetMapping("/employees/{id}")
    private Employee getFlights(@PathVariable("id") int id) {
        return empService.getById(id);
    }

    @DeleteMapping("/employees/{id}")
    private ResponseEntity<?> deleteFlight(@PathVariable("id") int id) {
        empService.delete(id);
        return new ResponseEntity<>("Successfully deleted with id " + id, HttpStatus.OK);
    }

    @PostMapping("/employees")
    private ResponseEntity<?> saveFlightDetails(@RequestBody Employee employee) {
        empService.saveOrUpdate(employee);
        return new ResponseEntity<>("Successfully Saved with Details ", HttpStatus.OK);
    }

    @PutMapping("/employees")
    private ResponseEntity<?> updateFlightDetails(@RequestBody Employee employee) {
        empService.saveOrUpdate(employee);
        return new ResponseEntity<>("Successfully Updated with Details ", HttpStatus.OK);
    }

}