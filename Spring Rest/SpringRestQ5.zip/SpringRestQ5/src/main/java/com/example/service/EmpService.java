package com.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.model.Employee;
import com.example.repo.DaoRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpService {
	@Autowired
	DaoRepo daoRepo;
	public List<Employee> getList()
	{
		List<Employee> EmpList = new ArrayList<Employee>();
		daoRepo.findAll().forEach(List1 -> EmpList.add(List1));
		return EmpList;
	}
	public Employee getById(long id)
	{
		return daoRepo.findById(id).get();
	}

	public void saveOrUpdate(Employee emp)
	{
		daoRepo.save(emp);
	}

	public void delete(long id)
	{
		daoRepo.deleteById(id);
	}

	public void update(Employee emp, int id)
	{
		daoRepo.save(emp);
	}
}