package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springrest9 {



    public static void main(String[] args) {
        SpringApplication.run(Springrest9.class, args);
    }

}
