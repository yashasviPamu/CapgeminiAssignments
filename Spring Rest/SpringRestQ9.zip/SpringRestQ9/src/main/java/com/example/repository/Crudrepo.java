package com.example.repository;

import com.example.model.customer;
import org.springframework.data.repository.CrudRepository;


public interface Crudrepo extends CrudRepository<customer, String>{
}